#!/bin/bash

/bin/mv /usr/libexec/CrashHousekeeping /usr/libexec/CrashHousekeeping_

/bin/mv /System/Library/LaunchDaemons/* /Library/LaunchDaemons

/bin/mv /Library/LaunchDaemons/bootps.plist /System/Library/LaunchDaemons
/bin/mv /Library/LaunchDaemons/com.apple.CrashHousekeeping.plist /System/Library/LaunchDaemons
/bin/mv /Library/LaunchDaemons/com.apple.jetsamproperties* /System/Library/LaunchDaemons
/bin/mv /Library/LaunchDaemons/com.apple.MobileFileIntegrity.plist /System/Library/LaunchDaemons
/bin/mv /Library/LaunchDaemons/com.apple.mobile.softwareupdated.plist /tmp
/bin/mv /Library/LaunchDaemons/com.apple.softwareupdateservicesd.plist /tmp

/bin/mv /reloader /usr/libexec/CrashHousekeeping
